package inheritance;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String args[]) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction(); 
		
		transaction.begin();
		
		Project project=new Project(101,"CITI Bank");
		
		Module module=new Module();
		module.setProjectId(121);
		module.setProjectName("FS");
		module.setModuleName("Login Module");
		
		Task task=new Task();
		task.setProjectId(211);
		task.setTaskDate(LocalDate.of(2005, 06, 30));
		task.setProjectName("Digital");
		task.setTaskDate(LocalDate.of(2001, 01, 01));
		task.setModuleName("Validation");
		task.setTaskDate(LocalDate.of(1947, 8, 15));
		task.setTaskName("Client Side Validate");
		task.setTaskDate(LocalDate.now());
		entityManager.persist(project);
		entityManager.persist(module);
		entityManager.persist(task);
		
		transaction.commit();
		entityManager.close();
	}
}

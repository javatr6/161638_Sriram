package com.cap.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		EntityTransaction transaction =entityManager.getTransaction();
		
		transaction.begin();
		
		
		Customer c1 =new Customer("Sri", "Ram", 50000.0);
		Address address = new Address(101, "Vizag", c1);
		
		entityManager.persist(c1); 
		entityManager.persist(address);
		
		transaction.commit();
		entityManager.close();
		

	}

}

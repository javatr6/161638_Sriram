package com.cap.onetoone;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int cusId;
	private String firstName;
	private String lastName;
	private Double regFee;
	
	public Customer() {
		super();
	}
	
	
	
	public Customer(String firstName, String lastName, Double regFee) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
	}



	public Customer(int cusId, String firstName, String lastName, Double regFee) {
		super();
		this.cusId = cusId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regFee = regFee;
	}

	public int getCusId() {
		return cusId;
	}
	public void setCusId(int cusId) {
		this.cusId = cusId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getRegFee() {
		return regFee;
	}
	public void setRegFee(Double regFee) {
		this.regFee = regFee;
	}
	@Override
	public String toString() {
		return "Customer [cusId=" + cusId + ", firstName=" + firstName + ", lastName=" + lastName + ", regFee=" + regFee
				+ "]";
	}
	
	
}

package com.cap.onetomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		EntityTransaction transaction =entityManager.getTransaction();
		
		transaction.begin();
		
		Company tcs = new Company("TCS Consultancy Services");
		Company capg = new Company("Capgemini Consultancy Services");		
		
		Employee employee = new Employee(1001,"Sri", tcs);
		employee.setRegDate(LocalDate.now());
		Employee employee1 = new Employee(1002,"Ram", tcs);
		employee1.setRegDate(LocalDate.of(1997, 05, 23));

		Employee employee2 = new Employee(1003,"Neeraj", capg);	
		employee2.setRegDate(LocalDate.of(2015, 12, 25));

		Employee employee3 = new Employee(1004,"Manoj", capg);
		employee3.setRegDate(LocalDate.of(2012, 12, 12));

		entityManager.persist(tcs);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		
		transaction.commit();
		entityManager.close();

	}

}

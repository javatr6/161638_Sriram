package com.capg.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.sun.jdi.event.EventSet;

public class mainClass {

	public static void main(String[] args) {
EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		EntityTransaction transaction =entityManager.getTransaction();
		
		transaction.begin();
		
		Events java = new Events();
		java.setEventId("101-JAVA");
		java.setEventName("JAVA");
		java.setEveDate(LocalDate.now());
		
		Events oracle = new Events();
		oracle.setEventId("102-ORACLE");
		oracle.setEventName("ORACLE");
		oracle.setEveDate(LocalDate.of(2016, 10, 02));
		
		Events dotnet = new Events();
		dotnet.setEventId("103-DOTNET");
		dotnet.setEventName("DOTNET");
		dotnet.setEveDate(LocalDate.of(2012, 11, 10));
		
		Delegates tom = new Delegates(1, "tom");
		Delegates jack = new Delegates(2, "jack");
		Delegates tim = new Delegates(3, "tim");
		Delegates lee = new Delegates(4, "lee");
		Delegates thomson = new Delegates(5, "thomson");
		Delegates kamal = new Delegates(6, "kamal");
		
		tom.getEvents().add(java);
		tom.getEvents().add(oracle);
		tim.getEvents().add(java);
		lee.getEvents().add(oracle);
		tim.getEvents().add(dotnet);
		thomson.getEvents().add(oracle);
		kamal.getEvents().add(java);
		jack.getEvents().add(oracle);
		
		entityManager.persist(tim);
		entityManager.persist(tom);
		entityManager.persist(thomson);
		entityManager.persist(lee);
		entityManager.persist(kamal);
		entityManager.persist(jack);
		entityManager.persist(java);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		
		transaction.commit();
		entityManager.close();
	}

}

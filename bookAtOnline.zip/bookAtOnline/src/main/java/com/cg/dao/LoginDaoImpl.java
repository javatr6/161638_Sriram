package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.model.LoginBean;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginbean) {
		String sql="select * from adminlogin where username = ? and userpassword = ?";
		
		try(PreparedStatement preparedstatement=getMySQLDBConnection().prepareStatement(sql);){
		
		preparedstatement.setString(1, loginbean.getUsername());
		preparedstatement.setString(2, loginbean.getUserpassword());
			ResultSet rs = preparedstatement.executeQuery();
					
				if(rs.next())
					return true;
				
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	private Connection getMySQLDBConnection() {
		Connection con=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb", "root", "India123");
					return con;
		}catch(SQLException e) {
			e.printStackTrace();
		}catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}

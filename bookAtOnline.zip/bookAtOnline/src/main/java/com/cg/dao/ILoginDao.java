package com.cg.dao;

import com.cg.model.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginbean);
}

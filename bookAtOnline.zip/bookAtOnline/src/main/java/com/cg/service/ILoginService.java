package com.cg.service;

import com.cg.model.LoginBean;

public interface ILoginService {
	public boolean isValidLogin(LoginBean loginbean);
}

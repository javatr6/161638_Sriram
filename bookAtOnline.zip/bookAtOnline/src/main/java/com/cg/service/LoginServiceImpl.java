package com.cg.service;

import com.cg.dao.ILoginDao;
import com.cg.dao.LoginDaoImpl;
import com.cg.model.LoginBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDao iLoginDao = new LoginDaoImpl();
	@Override
	public boolean isValidLogin(LoginBean loginbean) {
		if(iLoginDao.isValidLogin(loginbean)) {
			return true;	
			}
		return false;
	}



}

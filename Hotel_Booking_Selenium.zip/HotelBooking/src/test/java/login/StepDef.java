package login;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
public static WebDriver driver;
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver","D:\\\\Users\\\\sbheemal\\\\Desktop\\\\drivers\\\\chromedriver.exe");
		 driver = new ChromeDriver();
		
		 
	}
	@Given("^Open Login Page$")
	public void open_Login_Page() throws Throwable {
		 driver.get("http://localhost:8081/HotelBooking/");
	}

	@Given("^Verify Login page Heading$")
	public void verify_Login_page_Heading() throws Throwable {
		WebElement we=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
		String s=we.getText();
		assertEquals(s,"Hotel Booking Application");
	}

	@When("^Username is Empty$")
	public void username_is_Empty() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.name("userName")).sendKeys("");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click(); 
	
		
	}

	@Then("^Error username message$")
	public void error_username_message() throws Throwable {
	    System.out.println("Username not entered");
	}

	@When("^password is Empty$")
	public void password_is_Empty() throws Throwable {
		
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click(); 

		 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	@Then("^Error password message$")
	public void error_password_message() throws Throwable {
	    System.out.println("Password not entered");
	}

	@When("^Username and password is valid$")
	public void username_and_password_is_valid() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click(); 

	   System.out.println("Valid");

	}

	@Then("^Enter into HotelBooking Form$")
	public void enter_into_HotelBooking_Form() throws Throwable {
	   System.out.println("Entered into Hotel Booking Form");
	}
	
	@When("^Username and password is invalid$")
	public void username_and_password_is_invalid() throws Throwable {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.name("userName")).sendKeys("capgemini");
		driver.findElement(By.name("userPwd")).sendKeys("capg@1234");
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click(); 
	   System.out.println("inValid");

	}

	@Then("^show alertbox$")
	public void show_alertbox() throws Throwable {
	   System.out.println("Entered into Hotel Booking Form");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	   driver.switchTo().alert().accept();
	}

}
